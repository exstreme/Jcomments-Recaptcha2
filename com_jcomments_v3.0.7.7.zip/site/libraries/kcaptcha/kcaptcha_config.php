<?php

defined('_JEXEC') or die;

$alphabet = "0123456789abcdefghijklmnopqrstuvwxyz";
$allowed_symbols = "23456789abcdeghkmnpqsuvxyz";
$fontsdir = 'fonts';	
$length = 5;
$width = 121;
$height = 60;
$fluctuation_amplitude = 5;
$no_spaces = true;
$show_credits = false;
$credits = 'www.joomlatune.ru';
$foreground_color = array(180, 180, 180);
$background_color = array(246, 246, 246);
$jpeg_quality = 90;
?>